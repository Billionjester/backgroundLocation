package com.marianhello.bgloc.test;

abstract public class TestConstants {
    public static final String Authority = "com.marianhello.app.mauron85.bgloc.provider";
}
