Background Geolocation for Android

[![CircleCI](https://circleci.com/gh/mauron85/background-geolocation-android/tree/master.svg?style=shield)](https://circleci.com/gh/mauron85/background-geolocation-android/tree/master)

used by:

* [react-native-background-geolocation](https://github.com/mauron85/react-native-background-geolocation)

* [cordova-plugin-background-geolocation](https://github.com/mauron85/cordova-plugin-background-geolocation)
