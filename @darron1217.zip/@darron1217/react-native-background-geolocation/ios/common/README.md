Background Geolocation for iOS

used by:

* [react-native-background-geolocation](https://github.com/mauron85/react-native-background-geolocation)

* [cordova-plugin-background-geolocation](https://github.com/mauron85/cordova-plugin-background-geolocation)