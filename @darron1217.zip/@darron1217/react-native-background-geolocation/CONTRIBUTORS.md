Many thanks to all contributors

* [christocracy](https://github.com/christocracy)
* [huttj](https://github.com/huttj)
* [erikkemperman](https://github.com/erikkemperman)
* [codebling](https://github.com/codebling)
* [pmwisdom](https://github.com/pmwisdom)
* [dobrynia](https://github.com/dobrynia)
